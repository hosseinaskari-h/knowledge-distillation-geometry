"""
Efficient storage for experiment data
HDF5 for embeddings, SQLite for metadata
"""
import h5py
import sqlite3
import numpy as np
import json
import time
import torch
from pathlib import Path
from typing import Dict, List, Optional

from src.core.environment import Episode, Turn
from src.core.agent import AgentOutput


class ExperimentStorage:
    """Efficient storage for large-scale experiments"""

    def __init__(self, experiment_dir: Path):
        self.experiment_dir = Path(experiment_dir)
        self.experiment_dir.mkdir(parents=True, exist_ok=True)

        self.embeddings_path = self.experiment_dir / "embeddings.h5"
        self.metadata_path = self.experiment_dir / "metadata.db"

        self._init_hdf5()
        self._init_sqlite()

    def _init_hdf5(self):
        """Initialize HDF5 file structure"""
        with h5py.File(self.embeddings_path, 'a') as f:
            if 'episodes' not in f:
                f.create_group('episodes')

    def _init_sqlite(self):
        """Initialize SQLite database schema"""
        conn = sqlite3.connect(self.metadata_path)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                id TEXT PRIMARY KEY,
                timestamp REAL,
                num_turns INTEGER,
                total_reward REAL,
                metadata TEXT
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS turns (
                episode_id TEXT,
                turn_number INTEGER,
                agent_name TEXT,
                text TEXT,
                embedding_path TEXT,
                FOREIGN KEY (episode_id) REFERENCES episodes(id)
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                episode_id TEXT,
                metric_name TEXT,
                metric_value REAL,
                FOREIGN KEY (episode_id) REFERENCES episodes(id)
            )
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_turns_episode ON turns(episode_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_metrics_episode ON metrics(episode_id)
        """)

        conn.commit()
        conn.close()

    def save_episode(self, episode: Episode, metrics: Dict = None):
        """Save episode data"""

        # Save embeddings to HDF5
        with h5py.File(self.embeddings_path, 'a') as f:
            episodes_group = f['episodes']

            # Check if episode already exists
            if episode.id in episodes_group:
                del episodes_group[episode.id]

            ep_group = episodes_group.create_group(episode.id)

            for i, turn in enumerate(episode.turns):
                turn_group = ep_group.create_group(f'turn_{i}')

                # Save embedding
                embedding = turn.output.get_last_embedding()
                if isinstance(embedding, torch.Tensor):
                    embedding = embedding.detach().cpu().numpy()
                turn_group.create_dataset('embedding', data=embedding)

                # Optionally save hidden states (compressed) for first and last turns
                if turn.output.hidden_states is not None:
                    if i == 0 or i == len(episode.turns) - 1:
                        try:
                            # Get last step hidden states
                            last_step = turn.output.hidden_states[-1]
                            if isinstance(last_step, tuple):
                                hidden_data = np.array([
                                    h.detach().cpu().numpy() if isinstance(h, torch.Tensor) else h
                                    for h in last_step
                                ])
                            else:
                                hidden_data = last_step.detach().cpu().numpy() if isinstance(last_step, torch.Tensor) else last_step
                            turn_group.create_dataset(
                                'hidden_states',
                                data=hidden_data,
                                compression='gzip'
                            )
                        except Exception:
                            pass  # Skip if hidden states can't be saved

        # Save metadata to SQLite
        conn = sqlite3.connect(self.metadata_path)

        # Check if episode exists and delete if so
        conn.execute("DELETE FROM episodes WHERE id = ?", (episode.id,))
        conn.execute("DELETE FROM turns WHERE episode_id = ?", (episode.id,))
        conn.execute("DELETE FROM metrics WHERE episode_id = ?", (episode.id,))

        # Episode metadata
        conn.execute("""
            INSERT INTO episodes VALUES (?, ?, ?, ?, ?)
        """, (
            episode.id,
            time.time(),
            len(episode.turns),
            episode.metadata.get('total_reward', 0.0),
            json.dumps(episode.metadata)
        ))

        # Turn metadata
        for i, turn in enumerate(episode.turns):
            conn.execute("""
                INSERT INTO turns VALUES (?, ?, ?, ?, ?)
            """, (
                episode.id,
                i,
                turn.agent_name,
                turn.output.text,
                f'episodes/{episode.id}/turn_{i}/embedding'
            ))

        # Additional metrics
        if metrics:
            for metric_name, metric_value in metrics.items():
                if isinstance(metric_value, (int, float)):
                    conn.execute("""
                        INSERT INTO metrics VALUES (?, ?, ?)
                    """, (episode.id, metric_name, float(metric_value)))

        conn.commit()
        conn.close()

    def load_episode(self, episode_id: str) -> Episode:
        """Load complete episode"""
        # Load metadata
        conn = sqlite3.connect(self.metadata_path)
        cursor = conn.execute("""
            SELECT timestamp, num_turns, total_reward, metadata
            FROM episodes WHERE id = ?
        """, (episode_id,))

        row = cursor.fetchone()
        if row is None:
            conn.close()
            raise ValueError(f"Episode {episode_id} not found")

        _, num_turns, total_reward, metadata_json = row
        metadata = json.loads(metadata_json)

        # Load turns
        cursor = conn.execute("""
            SELECT turn_number, agent_name, text, embedding_path
            FROM turns WHERE episode_id = ?
            ORDER BY turn_number
        """, (episode_id,))

        turns = []
        with h5py.File(self.embeddings_path, 'r') as f:
            for turn_num, agent_name, text, emb_path in cursor:
                # Load embedding
                embedding = torch.from_numpy(f[emb_path][()])

                # Create minimal AgentOutput
                output = AgentOutput(
                    text=text,
                    tokens=torch.tensor([]),
                    embeddings=embedding,
                )

                turn = Turn(
                    agent_name=agent_name,
                    output=output,
                    step=turn_num
                )
                turns.append(turn)

        conn.close()

        episode = Episode(
            id=episode_id,
            turns=turns,
            initial_prompt=turns[0].output.text if turns else "",
            metadata=metadata
        )

        return episode

    def get_all_episode_ids(self) -> List[str]:
        """Get list of all episode IDs"""
        conn = sqlite3.connect(self.metadata_path)
        cursor = conn.execute("SELECT id FROM episodes ORDER BY timestamp")
        episode_ids = [row[0] for row in cursor]
        conn.close()
        return episode_ids

    def get_embeddings_for_episodes(self, episode_ids: List[str]) -> np.ndarray:
        """
        Get all embeddings for given episodes
        Returns: [n_total_turns, embedding_dim]
        """
        embeddings = []

        with h5py.File(self.embeddings_path, 'r') as f:
            for ep_id in episode_ids:
                if ep_id in f['episodes']:
                    ep_group = f['episodes'][ep_id]
                    for turn_key in sorted(ep_group.keys(), key=lambda x: int(x.split('_')[1])):
                        turn_group = ep_group[turn_key]
                        emb = turn_group['embedding'][()]
                        embeddings.append(emb)

        return np.array(embeddings) if embeddings else np.array([])

    def get_metrics(self, episode_ids: Optional[List[str]] = None) -> Dict[str, List[float]]:
        """Get metrics for episodes"""
        conn = sqlite3.connect(self.metadata_path)

        if episode_ids:
            placeholders = ','.join('?' * len(episode_ids))
            cursor = conn.execute(f"""
                SELECT metric_name, metric_value
                FROM metrics WHERE episode_id IN ({placeholders})
            """, episode_ids)
        else:
            cursor = conn.execute("SELECT metric_name, metric_value FROM metrics")

        metrics = {}
        for name, value in cursor:
            if name not in metrics:
                metrics[name] = []
            metrics[name].append(value)

        conn.close()
        return metrics

    def get_episode_count(self) -> int:
        """Get total number of episodes"""
        conn = sqlite3.connect(self.metadata_path)
        cursor = conn.execute("SELECT COUNT(*) FROM episodes")
        count = cursor.fetchone()[0]
        conn.close()
        return count
