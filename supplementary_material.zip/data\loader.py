"""
Data loader utilities
"""
import numpy as np
from pathlib import Path
from typing import List, Optional, Iterator

from .storage import ExperimentStorage
from src.core.environment import Episode


class ExperimentLoader:
    """Load experiment data for analysis"""

    def __init__(self, experiment_dir: Path):
        self.storage = ExperimentStorage(experiment_dir)

    def load_all_episodes(self) -> List[Episode]:
        """Load all episodes"""
        episode_ids = self.storage.get_all_episode_ids()
        return [self.storage.load_episode(eid) for eid in episode_ids]

    def load_episodes_batch(self, batch_size: int = 100) -> Iterator[List[Episode]]:
        """Load episodes in batches for memory efficiency"""
        episode_ids = self.storage.get_all_episode_ids()

        for i in range(0, len(episode_ids), batch_size):
            batch_ids = episode_ids[i:i + batch_size]
            yield [self.storage.load_episode(eid) for eid in batch_ids]

    def get_all_embeddings(self) -> np.ndarray:
        """Get all embeddings from all episodes"""
        episode_ids = self.storage.get_all_episode_ids()
        return self.storage.get_embeddings_for_episodes(episode_ids)

    def get_embeddings_range(self, start_episode: int, end_episode: int) -> np.ndarray:
        """Get embeddings for episode range"""
        episode_ids = self.storage.get_all_episode_ids()[start_episode:end_episode]
        return self.storage.get_embeddings_for_episodes(episode_ids)

    def get_embeddings_for_phase(self, phase: str) -> np.ndarray:
        """
        Get embeddings for developmental phase

        Args:
            phase: 'exploration' (0-10k), 'consolidation' (10k-30k), 'maturation' (30k+)
        """
        episode_ids = self.storage.get_all_episode_ids()
        n = len(episode_ids)

        if phase == 'exploration':
            start, end = 0, min(10000, n)
        elif phase == 'consolidation':
            start, end = 10000, min(30000, n)
        elif phase == 'maturation':
            start, end = 30000, n
        else:
            raise ValueError(f"Unknown phase: {phase}")

        return self.get_embeddings_range(start, end)

    def get_episode_count(self) -> int:
        """Get total episode count"""
        return self.storage.get_episode_count()

    def get_metrics(self, metric_names: Optional[List[str]] = None) -> dict:
        """Get metrics, optionally filtered by name"""
        all_metrics = self.storage.get_metrics()

        if metric_names:
            return {k: v for k, v in all_metrics.items() if k in metric_names}
        return all_metrics
