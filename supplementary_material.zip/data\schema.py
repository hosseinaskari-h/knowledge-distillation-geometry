"""
Data schema definitions
"""
from dataclasses import dataclass
from typing import Dict, List, Optional
import numpy as np


@dataclass
class EmbeddingData:
    """Embedding data for a single turn"""
    embedding: np.ndarray  # [hidden_dim]
    agent_name: str
    step: int
    episode_id: str


@dataclass
class EpisodeData:
    """Episode data for analysis"""
    id: str
    embeddings: np.ndarray  # [num_turns, hidden_dim]
    agent_names: List[str]
    texts: List[str]
    total_reward: float
    metadata: Dict


@dataclass
class ExperimentSummary:
    """Summary statistics for experiment"""
    num_episodes: int
    num_turns_total: int
    embedding_dim: int
    agents: List[str]
    mean_reward: float
    std_reward: float
    mean_turns_per_episode: float


def compute_experiment_summary(loader) -> ExperimentSummary:
    """Compute summary statistics from loader"""
    metrics = loader.get_metrics()
    episode_ids = loader.storage.get_all_episode_ids()

    # Get sample embedding for dimension
    if episode_ids:
        sample_embs = loader.storage.get_embeddings_for_episodes([episode_ids[0]])
        embedding_dim = sample_embs.shape[1] if len(sample_embs) > 0 else 0
    else:
        embedding_dim = 0

    # Get agents from first episode
    if episode_ids:
        first_ep = loader.storage.load_episode(episode_ids[0])
        agents = list(set(turn.agent_name for turn in first_ep.turns))
    else:
        agents = []

    # Compute stats
    rewards = metrics.get('total_reward', [])
    num_turns = metrics.get('num_turns', [])

    return ExperimentSummary(
        num_episodes=len(episode_ids),
        num_turns_total=sum(num_turns) if num_turns else 0,
        embedding_dim=embedding_dim,
        agents=agents,
        mean_reward=np.mean(rewards) if rewards else 0.0,
        std_reward=np.std(rewards) if rewards else 0.0,
        mean_turns_per_episode=np.mean(num_turns) if num_turns else 0.0,
    )
